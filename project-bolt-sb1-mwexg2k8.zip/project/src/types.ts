export interface Phase {
  id: string;
  name: string;
  description: string;
  color: string;
  bgColor: string;
  textColor: string;
  dotColor: string;
}

export interface Example {
  id: string;
  name: string;
  code: string;
}