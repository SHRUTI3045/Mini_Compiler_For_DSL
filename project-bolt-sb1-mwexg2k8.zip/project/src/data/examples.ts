import { Example } from '../types';

export const examples: Example[] = [
  {
    id: 'arithmetic',
    name: 'Arithmetic Expression',
    code: `// Simple arithmetic expression
x = 5;
y = 10;
z = x + y * 2;
`
  },
  {
    id: 'function',
    name: 'Function Definition',
    code: `// Function definition
function add(a, b) {
  return a + b;
}

result = add(5, 10);
`
  },
  {
    id: 'conditional',
    name: 'Conditional Statement',
    code: `// Conditional logic
x = 10;
if (x > 5) {
  result = "x is greater than 5";
} else {
  result = "x is not greater than 5";
}
`
  },
  {
    id: 'loop',
    name: 'Loop Statement',
    code: `// Loop example
sum = 0;
for (i = 1; i <= 10; i = i + 1) {
  sum = sum + i;
}
// sum will be 55
`
  }
];