import { Phase } from '../types';

export const phases: Phase[] = [
  {
    id: 'lexical',
    name: 'Lexical Analysis',
    description: 'Breaks down source code into tokens, identifying keywords, identifiers, operators, and more. This phase transforms raw text into meaningful symbols for the compiler.',
    color: '#F472B6', // Pink
    bgColor: '#FCE7F3',
    textColor: '#831843',
    dotColor: '#F472B6'
  },
  {
    id: 'syntax',
    name: 'Syntax Analysis',
    description: 'Analyzes tokens to create a parse tree or abstract syntax tree (AST), representing the grammatical structure of the code according to defined language rules.',
    color: '#A78BFA', // Purple
    bgColor: '#EDE9FE',
    textColor: '#5B21B6',
    dotColor: '#A78BFA'
  },
  {
    id: 'semantic',
    name: 'Semantic Analysis',
    description: 'Checks for semantic errors, type checking, and ensures the code follows language rules that cannot be expressed by syntax alone.',
    color: '#60A5FA', // Blue
    bgColor: '#DBEAFE',
    textColor: '#1E40AF',
    dotColor: '#60A5FA'
  },
  {
    id: 'intermediate',
    name: 'Intermediate Code',
    description: 'Generates an intermediate representation of the source code that is easier to analyze and optimize before final code generation.',
    color: '#34D399', // Green
    bgColor: '#D1FAE5',
    textColor: '#065F46',
    dotColor: '#34D399'
  },
  {
    id: 'optimization',
    name: 'Code Optimization',
    description: 'Improves the intermediate code by making it more efficient in terms of speed, memory usage, or other performance metrics.',
    color: '#FBBF24', // Yellow
    bgColor: '#FEF3C7',
    textColor: '#92400E',
    dotColor: '#FBBF24'
  },
  {
    id: 'generation',
    name: 'Code Generation',
    description: 'Produces the final target code, which could be machine code, bytecode, or another programming language depending on the compiler type.',
    color: '#F87171', // Red
    bgColor: '#FEE2E2',
    textColor: '#991B1B',
    dotColor: '#F87171'
  }
];