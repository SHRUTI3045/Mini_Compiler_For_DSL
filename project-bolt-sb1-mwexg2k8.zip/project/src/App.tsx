import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { PhaseSelector } from './components/PhaseSelector';
import { CodeEditor } from './components/CodeEditor';
import { Output } from './components/Output';
import { Sidebar } from './components/Sidebar';
import { PhaseInfo } from './components/PhaseInfo';
import { phases } from './data/phases';
import { ExampleSelector } from './components/ExampleSelector';
import { examples } from './data/examples';

function App() {
  const [activePhase, setActivePhase] = useState(phases[0]);
  const [code, setCode] = useState(examples[0].code);
  const [output, setOutput] = useState('');
  
  const handlePhaseChange = (phaseId: string) => {
    const newPhase = phases.find(p => p.id === phaseId) || phases[0];
    setActivePhase(newPhase);
    
    // Simulate processing output based on the phase
    processCode(code, newPhase.id);
  };
  
  const handleCodeChange = (newCode: string) => {
    setCode(newCode);
    processCode(newCode, activePhase.id);
  };
  
  const handleExampleSelect = (exampleCode: string) => {
    setCode(exampleCode);
    processCode(exampleCode, activePhase.id);
  };
  
  const processCode = (codeInput: string, phaseId: string) => {
    // Simulate processing for different phases
    // In a real implementation, this would call actual compiler functions
    
    setTimeout(() => {
      let result = '';
      
      switch (phaseId) {
        case 'lexical':
          result = simulateLexicalAnalysis(codeInput);
          break;
        case 'syntax':
          result = simulateSyntaxAnalysis(codeInput);
          break;
        case 'semantic':
          result = simulateSemanticAnalysis(codeInput);
          break;
        case 'intermediate':
          result = simulateIntermediateCodeGen(codeInput);
          break;
        case 'optimization':
          result = simulateOptimization(codeInput);
          break;
        case 'generation':
          result = simulateCodeGeneration(codeInput);
          break;
        default:
          result = 'Select a phase to see output';
      }
      
      setOutput(result);
    }, 300);
  };
  
  // Simulation functions for each phase
  const simulateLexicalAnalysis = (code: string) => {
    const tokens = code.split(/(\s+|[+\-*/()=;,])/g)
      .filter(token => token.trim() !== '');
    
    return tokens.map((token, index) => {
      let type = '';
      if (/^\d+$/.test(token)) type = 'NUMBER';
      else if (/^[a-zA-Z_]\w*$/.test(token)) type = 'IDENTIFIER';
      else if (['+', '-', '*', '/'].includes(token)) type = 'OPERATOR';
      else if (['(', ')'].includes(token)) type = 'PARENTHESIS';
      else if (token === '=') type = 'ASSIGNMENT';
      else if (token === ';') type = 'SEMICOLON';
      else if (/\s+/.test(token)) type = 'WHITESPACE';
      else type = 'UNKNOWN';
      
      return `Token(${index}): "${token}" - Type: ${type}`;
    }).join('\n');
  };
  
  const simulateSyntaxAnalysis = (code: string) => {
    // Simple syntax tree simulation
    let result = 'Abstract Syntax Tree:\n';
    
    const tokens = code.split(/(\s+|[+\-*/()=;,])/g)
      .filter(token => token.trim() !== '');
    
    let depth = 0;
    let inExpression = false;
    
    tokens.forEach(token => {
      if (token === '(') {
        result += `${' '.repeat(depth * 2)}Expression {\n`;
        depth++;
        inExpression = true;
      } else if (token === ')') {
        depth--;
        result += `${' '.repeat(depth * 2)}}\n`;
        inExpression = false;
      } else if (/^\d+$/.test(token)) {
        result += `${' '.repeat(depth * 2)}Number(${token})\n`;
      } else if (/^[a-zA-Z_]\w*$/.test(token)) {
        result += `${' '.repeat(depth * 2)}Identifier("${token}")\n`;
      } else if (['+', '-', '*', '/'].includes(token)) {
        result += `${' '.repeat(depth * 2)}Operator("${token}")\n`;
      } else if (token === '=') {
        result += `${' '.repeat(depth * 2)}Assignment\n`;
      } else if (token === ';') {
        result += `${' '.repeat(depth * 2)}EndStatement\n`;
      }
    });
    
    return result;
  };
  
  const simulateSemanticAnalysis = (code: string) => {
    // Simple semantic analysis simulation
    return `Semantic Analysis Results:
- Checked identifier scopes
- Validated type constraints
- No semantic errors found`;
  };
  
  const simulateIntermediateCodeGen = (code: string) => {
    // Simple intermediate code simulation
    return `Intermediate Representation:
  
temp1 = load a
temp2 = load b
temp3 = add temp1, temp2
store temp3, result`;
  };
  
  const simulateOptimization = (code: string) => {
    // Simple optimization simulation
    return `Optimized Intermediate Code:
  
// Constant folding applied
// Dead code eliminated
// Register allocation optimized
  
load a, r1
load b, r2
add r1, r2, r3
store r3, result`;
  };
  
  const simulateCodeGeneration = (code: string) => {
    // Simple code generation simulation
    return `Generated Target Code:
  
LOAD R1, [a]
LOAD R2, [b]
ADD R3, R1, R2
STORE [result], R3
HALT`;
  };

  return (
    <Layout>
      <Sidebar>
        <PhaseSelector 
          phases={phases}
          activePhase={activePhase.id}
          onPhaseChange={handlePhaseChange}
        />
        <ExampleSelector 
          examples={examples}
          onSelect={handleExampleSelect}
        />
      </Sidebar>
      <div className="flex flex-col w-full h-full">
        <PhaseInfo phase={activePhase} />
        <div className="flex flex-col md:flex-row gap-4 flex-grow">
          <CodeEditor 
            code={code} 
            onChange={handleCodeChange} 
            phaseColor={activePhase.color}
          />
          <Output 
            output={output} 
            phase={activePhase} 
          />
        </div>
      </div>
    </Layout>
  );
}

export default App;