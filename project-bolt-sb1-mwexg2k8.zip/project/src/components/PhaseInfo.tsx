import React from 'react';
import { Phase } from '../types';

interface PhaseInfoProps {
  phase: Phase;
}

export const PhaseInfo: React.FC<PhaseInfoProps> = ({ phase }) => {
  return (
    <div 
      className="mb-4 p-4 rounded-md"
      style={{ 
        backgroundColor: phase.bgColor,
        color: phase.textColor
      }}
    >
      <h2 className="text-xl font-semibold mb-2">{phase.name} Phase</h2>
      <p className="text-sm">{phase.description}</p>
    </div>
  );
};