import React from 'react';
import { Phase } from '../types';

interface OutputProps {
  output: string;
  phase: Phase;
}

export const Output: React.FC<OutputProps> = ({ output, phase }) => {
  return (
    <div className="flex-1 flex flex-col">
      <div 
        className="px-4 py-2 font-medium text-white rounded-t-md"
        style={{ backgroundColor: phase.color }}
      >
        {phase.name} Output
      </div>
      <pre className="flex-1 p-4 font-mono text-sm bg-white border border-gray-300 rounded-b-md overflow-auto whitespace-pre-wrap">
        {output || `Run your code to see ${phase.name.toLowerCase()} phase output`}
      </pre>
    </div>
  );
};