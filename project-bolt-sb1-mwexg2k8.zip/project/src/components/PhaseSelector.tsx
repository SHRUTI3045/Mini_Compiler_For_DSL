import React from 'react';
import { Phase } from '../types';
import { phases } from '../data/phases';

interface PhaseSelectorProps {
  phases: Phase[];
  activePhase: string;
  onPhaseChange: (phaseId: string) => void;
}

export const PhaseSelector: React.FC<PhaseSelectorProps> = ({ phases, activePhase, onPhaseChange }) => {
  return (
    <div className="mb-6">
      <h2 className="text-lg font-medium text-gray-800 mb-3">Compiler Phases</h2>
      <div className="space-y-2">
        {phases.map((phase) => (
          <button
            key={phase.id}
            onClick={() => onPhaseChange(phase.id)}
            className={`
              w-full text-left px-3 py-2 rounded-md transition-all duration-200
              ${activePhase === phase.id 
                ? `bg-${phase.color}-100 text-${phase.color}-800 font-medium` 
                : 'hover:bg-gray-100 text-gray-700'}
            `}
            style={{
              backgroundColor: activePhase === phase.id ? phase.bgColor : '',
              color: activePhase === phase.id ? phase.textColor : ''
            }}
          >
            <div className="flex items-center">
              <div 
                className="w-3 h-3 rounded-full mr-2"
                style={{ backgroundColor: phase.dotColor }}
              ></div>
              <span>{phase.name}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};