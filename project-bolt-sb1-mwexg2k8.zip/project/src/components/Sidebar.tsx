import React, { ReactNode } from 'react';

interface SidebarProps {
  children: ReactNode;
}

export const Sidebar: React.FC<SidebarProps> = ({ children }) => {
  return (
    <div className="w-full md:w-64 bg-white border-r border-gray-200 shadow-sm flex-shrink-0">
      <div className="p-4">
        {children}
      </div>
    </div>
  );
};