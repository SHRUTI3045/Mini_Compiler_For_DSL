import React, { useState } from 'react';
import { Code } from 'lucide-react';
import { Example } from '../types';

interface ExampleSelectorProps {
  examples: Example[];
  onSelect: (code: string) => void;
}

export const ExampleSelector: React.FC<ExampleSelectorProps> = ({ examples, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="mt-4">
      <h2 className="text-lg font-medium text-gray-800 mb-3">Example DSL Code</h2>
      <div className="space-y-2">
        {examples.map((example) => (
          <button
            key={example.id}
            onClick={() => onSelect(example.code)}
            className="w-full text-left px-3 py-2 rounded-md bg-gray-100 hover:bg-gray-200 transition-colors flex items-center"
          >
            <Code className="mr-2 text-gray-500" size={16} />
            <span className="text-sm">{example.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};