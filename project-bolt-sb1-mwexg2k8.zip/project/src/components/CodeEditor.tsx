import React from 'react';

interface CodeEditorProps {
  code: string;
  onChange: (code: string) => void;
  phaseColor: string;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ code, onChange, phaseColor }) => {
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
  };

  return (
    <div className="flex-1 flex flex-col">
      <div 
        className="px-4 py-2 font-medium text-white rounded-t-md"
        style={{ backgroundColor: phaseColor }}
      >
        Input DSL Code
      </div>
      <textarea
        value={code}
        onChange={handleChange}
        className="flex-1 p-4 font-mono text-sm bg-white border border-gray-300 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-b-md outline-none resize-none"
        placeholder="Enter your DSL code here..."
        spellCheck="false"
      />
    </div>
  );
};