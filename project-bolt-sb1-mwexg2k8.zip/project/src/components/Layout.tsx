import React, { ReactNode } from 'react';
import { BookOpen, Github } from 'lucide-react';

interface LayoutProps {
  children: ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-gradient-to-r from-purple-100 to-pink-100 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <h1 className="text-2xl font-semibold text-gray-800 flex items-center">
            <BookOpen className="mr-2 text-purple-500" size={24} />
            <span>DSL Compiler Explorer</span>
          </h1>
          <div className="flex items-center space-x-4">
            <a 
              href="https://github.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              <Github size={20} />
            </a>
            <button className="px-4 py-2 rounded-md bg-purple-500 text-white hover:bg-purple-600 transition-colors">
              Documentation
            </button>
          </div>
        </div>
      </header>
      
      <main className="flex-grow flex">
        {children}
      </main>
      
      <footer className="bg-white border-t border-gray-200 py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500">
          DSL Compiler Explorer © {new Date().getFullYear()} • A beautiful, interactive tool for exploring compiler phases
        </div>
      </footer>
    </div>
  );
};